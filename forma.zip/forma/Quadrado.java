/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package formas;

/**
 *
 * @author musas
 */
public class Quadrado extends Retangulo{
    double lado;
    
    Quadrado(String nome, double largura, double altura, double lado) {
        super(nome, largura, altura);
        this.lado = lado;
    }
    
    //sobrescrevendo o método calcularArea
    @Override
    double calcularArea() {
        return lado * lado;
    }
}
