/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package formas;

/**
 *
 * @author musas
 */
public class Circulo extends Forma{
    double raio;
    
    Circulo(String nome, double raio) {
        super(nome);
        this.raio = raio;
    }
    
    double calcularArea() {
        return Math.PI * raio * 2;
    }
}
