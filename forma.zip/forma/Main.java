/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package formas;

/**
 *
 * @author musas
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Circulo c1 = new Circulo("Circulo",6);
        c1.exibirNome();
        System.out.println("Área: " + c1.calcularArea());
        
        Retangulo r1 = new Retangulo("Retângulo",4,6);
        r1.exibirNome();
        System.out.println("Área: " + r1.calcularArea());
        
        Quadrado q1 = new Quadrado("Quadrado", 5, 5, 5);
        q1.exibirNome();
        System.out.println("Área: " + q1.calcularArea());
        
    }
    
}
